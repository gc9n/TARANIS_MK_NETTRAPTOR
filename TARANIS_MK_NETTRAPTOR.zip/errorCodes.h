
 // good to keep them < 20 because the screen is 20chr big
 const char  ERROR_CODE_0[]="No Error";
 const char  ERROR_CODE_1[]="FC not compat"; 
 const char  ERROR_CODE_2[]="MK3Mag not compat"; 
 const char  ERROR_CODE_3[]="no FC comm" ;
 const char  ERROR_CODE_4[]="no MK3Mag comm"; 
 const char  ERROR_CODE_5[]="no GPS comm"; 
 const char  ERROR_CODE_6[]="bad compass value";
 const char  ERROR_CODE_7[]="RC Signal lost"; 
 const char  ERROR_CODE_8[]="FC spi rx error"; 
 const char  ERROR_CODE_9[]="not used";
 const char  ERROR_CODE_10[]="ERR: FC Nick Gyro";
 const char  ERROR_CODE_11[]="ERR: FC Roll Gyro";
 const char  ERROR_CODE_12[]="ERR: FC Yaw Gyro";
 const char  ERROR_CODE_13[]="ERR: FC Nick ACC";
 const char  ERROR_CODE_14[]="ERR: FC Roll ACC";
 const char  ERROR_CODE_15[]="ERR: FC Z-ACC";
 const char  ERROR_CODE_16[]="ERR: Pressure sensor";
 const char  ERROR_CODE_17[]="ERR: FC I2C";
 const char  ERROR_CODE_18[]="ERR: Bl Missing";
 const char  ERROR_CODE_19[]="Mixer Error";
 const char  ERROR_CODE_20[]="FC: Carefree Error";

